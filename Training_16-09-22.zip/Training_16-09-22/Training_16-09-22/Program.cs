﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_16_09_22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Assignment_1_distinct_.Assg1();
            //Assignment2_days.Assg2();
            Assignment_3.Assg3();
        }
    }
}

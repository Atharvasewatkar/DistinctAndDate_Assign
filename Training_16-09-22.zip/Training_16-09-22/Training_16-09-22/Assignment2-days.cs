﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_16_09_22
{
    internal class Assignment2_days
    {
        public static void Assg2()
        {

            Console.WriteLine("Enter Month");
            int month = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Year");
            int year = int.Parse(Console.ReadLine());


            
            int daysInJuly = System.DateTime.DaysInMonth(year, month);
            Console.WriteLine(daysInJuly);

            

           
            Console.ReadLine();
        }
    }
}

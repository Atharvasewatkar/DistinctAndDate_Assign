﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_16_09_22
{
    internal class Assignment_3
    {

        public static void Assg3() 
        {
            Console.WriteLine("Enter no. of weeks for past date");
            int week = int.Parse(Console.ReadLine());
             DateTime dt = DateTime.Now;


            Console.WriteLine("Date before exact 3 weeks ago = "+dt.AddDays(-(7*week)));

            Console.ReadLine();
        }
    }
}

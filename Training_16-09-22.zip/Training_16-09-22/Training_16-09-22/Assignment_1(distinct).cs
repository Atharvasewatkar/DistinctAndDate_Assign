﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_16_09_22
{
    internal class Assignment_1_distinct_
    {
        public static void Assg1() 
        {
            List<String> list = new List<String>();// { "Ciscuit","Brade", "Apple", "Ciscuit", "Honey" };


            Console.WriteLine("Enter the number of product");
            int cnt = int.Parse(Console.ReadLine());
            for (int i = 0; i < cnt; i++)
            {
                Console.WriteLine("enter item");
                list.Add(Console.ReadLine());
            }
         var QuerySyntax= (from li in list
                           orderby li ascending
                           select li).Distinct();

            Console.WriteLine("List of disticnt and sorted items");
            foreach (var item in QuerySyntax)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }

    }
}
